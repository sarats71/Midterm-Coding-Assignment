package com.cisc181.core;

import java.util.UUID;

import com.cisc181.eNums.eMajor;

public class Course {
	UUID CourseID;
	String CourseName;
	int GradePoints;
	eMajor Major;

}
